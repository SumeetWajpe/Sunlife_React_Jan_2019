import React from  'react';
import Course from './course.component';

export default class ListOfCourses extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            allCourses:[
                            {id:1,title:'React',duration:'3 Days',price:5000,imageUrl:'https://cdn-images-1.medium.com/max/2000/1*HSisLuifMO6KbLfPOKtLow.jpeg'},
                            {id:2,title:'Redux',duration:'2 Days',price:3000,imageUrl:'https://redux.js.org/img/redux-logo-landscape.png'},
                            {id:3,title:'Vue',duration:'3 Days',price:7000,imageUrl:'https://cdn.shopify.com/s/files/1/0533/2089/files/vuejs-tutorial_2d2a853c-aa2f-44b0-80df-933b495f77f8.png?v=1509478492'},
                            {id:4,title:'.NET',duration:'8 Days',price:7000,imageUrl:'https://static.sinap.ps/blog/2014/Dec/nodejs_logo-1417834491072.png'},
                            {id:5,title:'Angular',duration:'4 Days',price:6000,imageUrl:'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Angular_full_color_logo.svg/250px-Angular_full_color_logo.svg.png'}
                         
                            ]}
    }

    Clickhandler(){      

        let aNewCourse = {
            id:this.state.allCourses[this.state.allCourses.length+1],
            title:this.refs.txtCourseName.value,
            duration:this.refs.txtCourseDuration.value,
            price:this.refs.txtCoursePrice.value,
            imageUrl:this.refs.txtCourseImageUrl.value
        }

        this.setState({allCourses:
            [...this.state.allCourses,aNewCourse]})    
    }  
    
   
    render(){

        var coursesTobecreated = this.state.allCourses.map(
            (course,index)=> <Course coursedetails={course} key={course.id} 
            ></Course>)
            return <div className="container">
                        <h1> List Of Courses </h1>    
                      
                         <div className="row" >
                         {coursesTobecreated}
                         </div>
                    
            </div> 
    }
}

    


