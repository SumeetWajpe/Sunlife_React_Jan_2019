// Code Here
import React from 'react';
import ReactDOM from 'react-dom';
import Basic,{Add,Product} from './basic.component';
import Button from './button.component';
import ListOfButtons from './listofbuttons.component';
import ListOfCourses from './listofcourses.component';


ReactDOM.render(<ListOfCourses />, document.getElementById('content'))
