import React from 'react';
import Button from './button.component';

export default class ListOfButtons extends React.Component{
    
    
    constructor(props){
            super(props);
            this.state ={list:[10,20,30,40,50]};
    }
    AddNewButton(){
        // set state !
        this.setState({list:[...this.state.list,+(this.refs.txtInput.value)]})
    }
    DeleteButtonHandler(){
        // set state - which does not have the element
        let theValue = this.refs.txtInput.value;
        let theNewList = this.state.list.filter(e=> e!=theValue);
        this.setState({list:theNewList});
        console.log(theNewList);
    }
    render(){
        let buttonsToBeCreated = this.state.list.map(
            (b,i)=> <Button initialCount={b} key={Math.random()} />
        )
        return <div>

                        Enter New Number : <input type="text" 
                        ref="txtInput"
                        className="form-control" />
                        <input type="button" value="Add"
                        className="btn btn-success"
                        onClick={this.AddNewButton.bind(this)}
                        />
                        <button className="btn btn-danger" 
                        onClick={this.DeleteButtonHandler.bind(this)}>
                                <span className="glyphicon glyphicon-trash">

                                </span>
                        </button>

                                   {buttonsToBeCreated}
                    </div>
    }
}