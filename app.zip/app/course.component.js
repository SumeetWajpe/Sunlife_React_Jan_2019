import React from  'react';

export default class CourseComponent extends React.Component{
    render(){
        return <div className="col-md-6 ">

                <div className="row coursestyle">
                <div className="col-md-6">
                    <img src={this.props.coursedetails.imageUrl} className="img-thumbnail" width="300px"  />
            
                    </div>
            <div className="col-md-4">
           
            <h2> {this.props.coursedetails.title} </h2>
            
                    <b> Duration : </b> {this.props.coursedetails.duration} <br/>
                    <b> Price : </b> {this.props.coursedetails.price} <br/>
            </div>
            <div className="col-md-2">
            <button className="btn btn-danger"
                     
                         ><span className="glyphicon glyphicon-trash"></span>
                         </button>
            </div>
                </div>
                  
        </div> 
                    

    }
}

    


