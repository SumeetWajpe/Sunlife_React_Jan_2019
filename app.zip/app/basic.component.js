import React from 'react';

export default class BasicComponent extends React.Component{
    render(){
        return <h1> JSX using Quickstart !</h1>
    }
}

export function Add(x,y){
    return x + y;
}


export function Product(x,y){
    return x * y;
}
