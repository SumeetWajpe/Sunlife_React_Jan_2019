import React from 'react';

export default class Button extends React.Component{
   
    constructor(props){
        super(props);
        this.state = {count:this.props.initialCount}
    }

   ClickHandler(){
       this.setState({count:this.state.count+1});
   }
    render(){
        return <button className="btn btn-primary" 
        onClick={this.ClickHandler.bind(this)}> {this.state.count} </button>
    }
}